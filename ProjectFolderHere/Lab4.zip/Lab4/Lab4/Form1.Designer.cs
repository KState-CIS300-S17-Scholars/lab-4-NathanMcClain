﻿namespace Lab4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.uxBoundLabel = new System.Windows.Forms.Label();
            this.uxBoundBox = new System.Windows.Forms.TextBox();
            this.uxFindPrimesButton = new System.Windows.Forms.Button();
            this.uxResultBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // uxBoundLabel
            // 
            this.uxBoundLabel.AutoSize = true;
            this.uxBoundLabel.Location = new System.Drawing.Point(52, 60);
            this.uxBoundLabel.Name = "uxBoundLabel";
            this.uxBoundLabel.Size = new System.Drawing.Size(144, 17);
            this.uxBoundLabel.TabIndex = 0;
            this.uxBoundLabel.Text = "Enter Positive Bound:";
            // 
            // uxBoundBox
            // 
            this.uxBoundBox.Location = new System.Drawing.Point(213, 60);
            this.uxBoundBox.Name = "uxBoundBox";
            this.uxBoundBox.Size = new System.Drawing.Size(177, 22);
            this.uxBoundBox.TabIndex = 1;
            this.uxBoundBox.Click += new System.EventHandler(this.uxFindPrimesClick);
            // 
            // uxFindPrimesButton
            // 
            this.uxFindPrimesButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxFindPrimesButton.Location = new System.Drawing.Point(128, 105);
            this.uxFindPrimesButton.Name = "uxFindPrimesButton";
            this.uxFindPrimesButton.Size = new System.Drawing.Size(225, 49);
            this.uxFindPrimesButton.TabIndex = 2;
            this.uxFindPrimesButton.Text = "Find Primes";
            this.uxFindPrimesButton.UseVisualStyleBackColor = true;
            this.uxFindPrimesButton.Click += new System.EventHandler(this.uxFindPrimesClick);
            // 
            // uxResultBox
            // 
            this.uxResultBox.Location = new System.Drawing.Point(37, 195);
            this.uxResultBox.Multiline = true;
            this.uxResultBox.Name = "uxResultBox";
            this.uxResultBox.ReadOnly = true;
            this.uxResultBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.uxResultBox.Size = new System.Drawing.Size(353, 199);
            this.uxResultBox.TabIndex = 3;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(431, 431);
            this.Controls.Add(this.uxResultBox);
            this.Controls.Add(this.uxFindPrimesButton);
            this.Controls.Add(this.uxBoundBox);
            this.Controls.Add(this.uxBoundLabel);
            this.Name = "Form1";
            this.Text = "Sieve of Eratosthenes";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label uxBoundLabel;
        private System.Windows.Forms.TextBox uxBoundBox;
        private System.Windows.Forms.Button uxFindPrimesButton;
        private System.Windows.Forms.TextBox uxResultBox;
    }
}

