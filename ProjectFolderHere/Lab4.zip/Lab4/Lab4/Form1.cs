﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void uxFindPrimesClick(object sender, EventArgs e)
        {
            uxResultBox.Text = "";
            SieveList list = new SieveList();
            list.BuildList(Convert.ToInt32(uxBoundBox.Text));
            list.FindPrimes();
            foreach (int num in list)
            {
                uxResultBox.Text += num + " ";
            }
        }
    }
}
