﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4
{
    class SieveList: IEnumerable<int>
    {
        private Node _head;
        private Node _tail;

        public SieveList()
        {
            _head = null;
            _tail = null;
        }

        public class Node
        {
            private int _data;
            private Node _next;

            public Node (int d)
            {
                _data = d;
                _next = null;
            }
            public Node Next
            {
                get
                {
                    return _next;
                }
                set
                {
                    _next = value;
                }
            }
            public int Data
            {
                get
                {
                    return _data;
                }
            }
        }

        public void BuildList(int bound)
        {
            for (int i = 2; i <= bound; i++)
            {
                Node newNode = new Node(i);
                if (i == 2)
                {
                    _head = newNode;
                    _tail = newNode;
                }
                else
                {
                    _tail.Next = newNode;
                    _tail = newNode;
                }
            }
        }
    
        public void FindPrimes()
        {
            Node current = _head;

            while(current != null)
            {
                Node temp = current;
                while(temp.Next != null)
                {
                    if (temp.Next.Data % current.Data == 0)
                    {
                        if (temp.Next != null)
                        {
                            temp.Next = temp.Next.Next;
                        }
                    }
                    else
                    {
                        temp = temp.Next;
                    }
                }
                current = current.Next;
            }    
        }

        public class SieveEnumerator : IEnumerator<int>
        {

            private Node current;

            public SieveEnumerator(Node h)
            {
                current = new Node(32);
                current.Next = h;
            }

            public int Current
            {
                get
                {
                    return current.Data;
                }
            }

            object IEnumerator.Current
            {
                get
                {
                    return current.Data;
                }
            }

            public void Dispose() { }

            public bool MoveNext()
            {
                if(current== null)
                {
                    return false;
                }
                else
                {
                    current = current.Next;
                    if(current == null)
                    {
                        return false;
                    }
                    else
                    {
                        return true;
                    }
                }
            }

            public void Reset()
            {
                throw new NotImplementedException();
            }
        }    

        public IEnumerator<int> GetEnumerator()
        {
            return new SieveEnumerator(_head);
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
    }
}
